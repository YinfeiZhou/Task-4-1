package com.deakin.studytimer;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


public final class MainActivity extends AppCompatActivity {
    private long startTime;
    private long record;
    private Handler handler;
    private long timeBase;
    private TextView timeTextView;
    private EditText taskView;
    private boolean isRunning;
    private Button playBtn;
    private Button pauseBtn;
    private Button recordBtn;
    private TextView lastLabel;
    private long seconds;
    private long minutes;
    private long actualTime;

    private final Runnable runnable = (new Runnable() {
        public void run() {
            MainActivity.this.record = SystemClock.uptimeMillis() - MainActivity.this.startTime;
            MainActivity.this.actualTime = MainActivity.this.record + MainActivity.this.timeBase;
            MainActivity.this.seconds = MainActivity.this.actualTime / (long) 1000 % (long) 60;
            MainActivity.this.minutes = MainActivity.this.actualTime / (long) 1000 / (long) 60;
            String time = String.format("%02d:%02d", MainActivity.this.minutes, MainActivity.this.seconds);
            MainActivity.this.timeTextView.setText( time);
            MainActivity.this.handler.postDelayed(this, 0L);
        }
    });

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        playBtn = findViewById(R.id.play_btn);
        pauseBtn = findViewById(R.id.pause_btn);
        recordBtn = findViewById(R.id.record_btn);
        taskView = findViewById(R.id.edit_task);
        lastLabel = findViewById(R.id.last_label);

        timeTextView = findViewById(R.id.time);

        playBtn.setOnClickListener((new OnClickListener() {
            public final void onClick(View it) {
                MainActivity.this.startTimer();
            }
        }));

        pauseBtn.setOnClickListener((new OnClickListener() {
            public final void onClick(View it) {
                MainActivity.this.pause();
            }
        }));

        recordBtn.setOnClickListener((new OnClickListener() {
            public final void onClick(View it) {
                MainActivity.this.recordTask();
            }
        }));
        this.handler = new Handler(Looper.getMainLooper());

        if (savedInstanceState != null) {

            this.isRunning = savedInstanceState.getBoolean("is_running");
            this.timeBase = savedInstanceState.getLong("time_base");
            this.record = savedInstanceState.getLong("record");
            this.startTime = savedInstanceState.getLong("start_time");
            this.actualTime = savedInstanceState.getLong("actual_time");
            this.minutes = savedInstanceState.getLong("minutes");
            this.seconds = savedInstanceState.getLong("seconds");
            if (isRunning) {
                handler.postDelayed(runnable, 0);
                playBtn.setEnabled(false);
                pauseBtn.setEnabled(true);
            } else {
                playBtn.setEnabled(true);
                pauseBtn.setEnabled(false);
            }

            timeTextView.setText(String.format("%02d:%02d", minutes, seconds));
        }

        SharedPreferences sharedPref = getPreferences(Context.MODE_PRIVATE);
        if (sharedPref.getString("last_task", null) != null) {
            long actualTime = sharedPref.getLong("last_time", 0);
            long seconds = actualTime / 1000 % 60;
            long minutes = actualTime / 1000 / 60;
            lastLabel.setText(String.format("You spent %02d:%02d on %s", minutes, seconds, sharedPref.getString("last_task", null)));
        }
    }

    private final void startTimer() {
        isRunning = true;
        startTime = SystemClock.uptimeMillis();
        handler.postDelayed(runnable, 0);
        playBtn.setEnabled(false);
        pauseBtn.setEnabled(true);
    }

    private final void pause() {
        isRunning = false;
        timeBase += record;
        handler.removeCallbacks(runnable);
        playBtn.setEnabled(true);
        pauseBtn.setEnabled(false);
    }

    private final void recordTask() {
        if (taskView.getText().toString().isEmpty() && record > 0) {
            return;
        }
        lastLabel.setText(String.format("You spent %02d:%02d on %s last time", minutes, seconds, taskView.getText().toString()));

        handler.removeCallbacks(runnable);
        SharedPreferences sharedPref = getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor myEdit = sharedPref.edit();
        myEdit.putString("last_task", taskView.getText().toString());
        myEdit.putLong("last_time", actualTime);
        myEdit.commit();
        playBtn.setEnabled(true);
        pauseBtn.setEnabled(false);
        isRunning = false;
        timeBase = 0;
        record = 0;
        actualTime = 0;
        seconds = 0;
        minutes = 0;
        timeTextView.setText("00:00");
    }

    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean("is_running", this.isRunning);
        outState.putLong("time_base", this.timeBase);
        outState.putLong("record", this.record);
        outState.putLong("start_time", this.startTime);
        outState.putLong("seconds", this.seconds);
        outState.putLong("minutes", this.minutes);
        outState.putLong("actual_time", this.actualTime);
    }
}
